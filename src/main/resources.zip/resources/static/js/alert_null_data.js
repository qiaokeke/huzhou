function nullData(){
    layer.open({
        content: '<div style="padding: 20px 80px;">该公司暂无数据</div>'
        ,btn: '确认'
    });
}