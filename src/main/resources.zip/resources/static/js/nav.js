/*
$(function() {
    //hasLogin = false;
    // hasLogin = true;
        if(!hasLogin){
            $("#user-icon").hide();
            $("#user-name").hide();
            $("#before-login").show();
        }
        else {
            $("#before-login").hide();
            $("#user-icon").show();
            $("#user-name").show();
        }
        // userHero = 'root';
        //  userHero = 'user';
        /!*园区管理者登录*!/
        if (userHero === 'root') {
            $("#menu-top li:nth-child(2) a").attr('href', 'rootIndexDnhgl')
            $("#menu-top li:nth-child(3) a").attr('href', 'rootYqfw')
            $("#top-my-menu a:nth-child(2)").attr('href', 'rootIndexDnhgl')
            $("#top-my-menu a:nth-child(3)").attr('href', 'rootYqfw')
        }
        /!*租户登陆*!/
        else if (userHero === 'user') {
            $("#menu-top li:nth-child(2) a").attr('href', 'userIndexDnhgl')
            $("#menu-top li:nth-child(3) a").attr('href', 'userYqfw')
            $("#top-my-menu a:nth-child(2)").attr('href', 'userIndexDnhgl')
            $("#top-my-menu a:nth-child(3)").attr('href', 'userYqfw')
        }

    })*/
